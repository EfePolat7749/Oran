<?php

namespace Oran;

use pocketmine\plugin\PluginBase;
use pocketmine\command\{Command, CommandSender, ConsoleCommandSender};
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\Config;
use Oran\Events\EventListener;
use Oran\Commands\Oran;

class Base extends PluginBase{

    private static $instance;

    public function onLoad(){
        self::$instance = $this;
    }

   public function onEnable(){
   @mkdir($this->getDataFolder());
   @mkdir($this->getDataFolder()."Oran/");
   $this->getServer()->getLogger()->notice("Eklenti Enabled Code By EfePolat7749");
 $this->getServer()->getCommandMap()->register("oran", new Oran($this)); 
   $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
   }
}