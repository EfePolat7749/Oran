<?php

namespace Oran\Commands;

use pocketmine\plugin\Plugin;
use pocketmine\command\{Command, CommandSender};
use pocketmine\utils\Config;
use pocketmine\{Player, Server};
use Oran\Base;
use jojoe77777\FormAPI\{ModalForm, SimpleForm, CustomForm};

class Oran extends Command{
	
	public function __construct(Base $plugin){
		parent::__construct("oran", "Oran", "/oran");
		$this->plugin = $plugin;
	}
	public function execute(CommandSender $o, string $label, array $args){
             if($o->hasPermission("oyuncu.oran")){
			$this->oranOyuncu($o);
     }
             if($o->hasPermission("vip.oran")){
			$this->oranVip($o);
     }
             if($o->hasPermission("vipplus.oran")){
			$this->oranvipplus($o);
     }
             if($o->hasPermission("mvip.oran")){
			$this->oranmvip($o);
     }
    if ($o->isOp()) {
     $this->oranmvip($o);
     }
	}
public function oranOyuncu(Player $o){
		$f = new CustomForm(function(Player $o, $args){
      $oran = new Config($this->plugin->getDataFolder() . "Oran/" . $o->getName() . ".yml", Config::YAML);
			if($args === null){
				return true;
			}
 if($args[1] == 1){
				$oran->set("Oran", "1x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e1x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
           if($args[1] == 2){
				$oran->set("Oran", "2x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e2x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 0){
				$oran->set("Oran", "0x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e0x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
		});
		$oran = new Config($this->plugin->getDataFolder()."Oran/".$o->getName().".yml", Config::YAML);
		$orani = $oran->get("Oran");
		$nick = $o->getName();
		$f->setTitle("Oran");
		$f->addLabel("§7Merhaba §6$nick \n§7Bu Menüde §eOranını §7Ayarlayabilirsin!\n\n§aEn Fazla Oran Değeri: §6$orani\n\n\n");
		$f->addSlider("§aKaydırarak Oranını Belirle!", 0,2);
           $f->sendToPlayer($o);
}
	public function oranVip(Player $o){
		$f = new CustomForm(function(Player $o, $args){
      $oran = new Config($this->plugin->getDataFolder() . "Oran/" . $o->getName() . ".yml", Config::YAML);
			if($args === null){
				return true;
			}
 if($args[1] == 1){
				$oran->set("Oran", "1x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e1x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
           if($args[1] == 2){
				$oran->set("Oran", "2x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e2x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 3){
				$oran->set("Oran", "3x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e3x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 4){
				$oran->set("Oran", "4x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e4x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 0){
				$oran->set("Oran", "0x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e0x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
		});
		$oran = new Config($this->plugin->getDataFolder()."Oran/".$o->getName().".yml", Config::YAML);
		$orani = $oran->get("Oran");
		$nick = $o->getName();
		$f->setTitle("Oran");
		$f->addLabel("§7Merhaba §6$nick \n§7Bu Menüde §eOranını §7Ayarlayabilirsin!\n\n§aEn Fazla Oran Değeri: §6$orani\n\n\n");
		$f->addSlider("§aKaydırarak Oranını Belirle!", 0,4);
           $f->sendToPlayer($o);
}
	public function oranvipplus(Player $o){
		$f = new CustomForm(function(Player $o, $args){
      $oran = new Config($this->plugin->getDataFolder() . "Oran/" . $o->getName() . ".yml", Config::YAML);
			if($args === null){
				return true;
			}
 if($args[1] == 1){
				$oran->set("Oran", "1x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e1x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
           if($args[1] == 2){
				$oran->set("Oran", "2x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e2x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 3){
				$oran->set("Oran", "3x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e3x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 4){
				$oran->set("Oran", "4x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e4x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 5){
				$oran->set("Oran", "5x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e5x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 6){
				$oran->set("Oran", "6x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e6x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 0){
				$oran->set("Oran", "0x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e0x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
		});
		$oran = new Config($this->plugin->getDataFolder()."Oran/".$o->getName().".yml", Config::YAML);
		$orani = $oran->get("Oran");
		$nick = $o->getName();
		$f->setTitle("Oran");
		$f->addLabel("§7Merhaba §6$nick \n§7Bu Menüde §eOranını §7Ayarlayabilirsin!\n\n§aEn Fazla Oran Değeri: §6$orani\n\n\n");
		$f->addSlider("§aKaydırarak Oranını Belirle!", 0,6);
           $f->sendToPlayer($o);
}
	public function oranmvip(Player $o){
		$f = new CustomForm(function(Player $o, $args){
      $oran = new Config($this->plugin->getDataFolder() . "Oran/" . $o->getName() . ".yml", Config::YAML);
			if($args === null){
				return true;
			}
 if($args[1] == 1){
				$oran->set("Oran", "1x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e1x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
           if($args[1] == 2){
				$oran->set("Oran", "2x");
				$oran->save();
				$mesaj =  "§8[§a!§8] §7Oranın §e2x  §7Olarak Güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 3){
				$oran->set("Oran", "3x");
				$oran->save();
				$mesaj =  "§aOranın 3x  olarak güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 4){
				$oran->set("Oran", "4x");
				$oran->save();
				$mesaj =  "§aOranın 4x  olarak güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 5){
				$oran->set("Oran", "5x");
				$oran->save();
				$mesaj =  "§aOranın 5x  olarak güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 6){
				$oran->set("Oran", "6x");
				$oran->save();
				$mesaj =  "§aOranın 6x  olarak güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 7){
				$oran->set("Oran", "7x");
				$oran->save();
				$mesaj =  "§aOranın 7x  olarak güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 8){
				$oran->set("Oran", "8x");
				$oran->save();
				$mesaj =  "§aOranın 8x  olarak güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
 if($args[1] == 0){
				$oran->set("Oran", "0x");
				$oran->save();
				$mesaj =  "§aOranın 0x  olarak güncellendi";
                    $this->msgf = $mesaj;
  $o->sendMessage("$mesaj");
			}
		});
		$oran = new Config($this->plugin->getDataFolder()."Oran/".$o->getName().".yml", Config::YAML);
		$orani = $oran->get("Oran");
		$nick = $o->getName();
		$f->setTitle("Oran");
		$f->addLabel("§aMerhaba §6$nick §aBu Menüde Oranini Ayarlayabilirsin!\n\n§aMax Oran: §6$orani\n\n\n");
		$f->addSlider("§aKaydırarak Oranını Belirle!", 0,8);
           $f->sendToPlayer($o);
}
}