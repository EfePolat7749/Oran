<?php

namespace Oran\Events;

use pocketmine\plugin\{Plugin, PluginBase};
use Oran\Base;
use pocketmine\event\Listener;
use pocketmine\{Player, Server};
use pocketmine\event\player\{PlayerJoinEvent, PlayerQuitEvent, PlayerInteractEvent};
use jojoe77777\FormAPI\{SimpleForm, ModalForm, CustomForm};
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\utils\Config;
use pocketmine\scheduler\Task;
//use SkyCore\Tasklar\JoinTask;
use pocketmine\command\{ConsoleCommandSender, CommandSender};
use pocketmine\Item\Item;
use onebone\economyapi\EconomyAPI;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
//use pocketmine\item\Item;
use pocketmine\block\Block;

class EventListener implements Listener{
	
	public $isim;
	 public $basitkasaid = 377;
   public $efsanekasaid = 399;
   public $vipkasaid = 376;
     public $elmasadetfiyati = 275;
     public $eid = 264;
     public $altinadetfiyati = 170;
     public $aid = 266;
     public $demiradetfiyati = 200;
     public $deid = 265;
     public $zumrutadetfiyati = 300;
     public $zuid = 388;
     public $komuradetfiyati = 85;
     public $komurid = 263;

	public function __construct(Base $plugin){
	$this->plugin = $plugin;
	}
    public function onJoin(PlayerJoinEvent $e){
    $o = $e->getPlayer();
   if(!(file_exists($this->plugin->getDataFolder() . "Oran/" . $o->getName() . ".yml"))){
   $oran = new Config($this->plugin->getDataFolder() . "Oran/" . $o->getName() . ".yml", Config::YAML,[
   "Oran" => "2x",
   "Tur" => "OYUNCU"
   ]);
   $oran->save();
}
}
 	public function blokKir(BlockBreakEvent $k){
	$o = $k->getPlayer();
	$dunya = $o->getLevel()->getFolderName();
	$isim = $o->getName();
   $oran = new Config($this->plugin->getDataFolder() . "Oran/" . $o->getName() . ".yml", Config::YAML);
	if($dunya = $isim){
	if($k->getBlock()->getId() == 4){
		if($oran->get("Oran") == "1x"){
			$this->birix($k);
		}elseif($oran->get("Oran") == "2x"){
			$this->ikix($k);			
		}elseif($oran->get("Oran") == "3x"){
			$this->ucix($k);			
	     }elseif($oran->get("Oran") == "4x"){
			$this->dix($k);		
         }elseif($oran->get("Oran") == "5x"){
			$this->besx($k);			
 	
		}elseif($oran->get("Oran") == "6x"){
			$this->altiix($k);			
		}elseif($oran->get("Oran") == "7x"){
			$this->yediix($k);			
 
		}elseif($oran->get("Oran") == "8x"){
			$this->sekizix($k);		
	}
	}
	}
}
	public function birix($k){
          $o = $k->getPlayer();
		$oran1 = rand(1,100);
		$oran2 = rand(1,150);
		$oran3 = rand(1,100);
		$d = $k->getPlayer()->getLevel()->getFolderName();
		$dunya = $this->plugin->getServer()->getLevelByName($d);
		$x = $k->getBlock()->getX();
		$y = $k->getBlock()->getY();
		$z = $k->getBlock()->getZ();

         switch($oran1){
          case 0:
          $o->getInventory()->addItem(Item::get($this->basitkasaid,0,1));
           $o->sendPopUp("§7~ §aWoow Sıradan Kasa Çıkardın! (1x) §7~");
          break;
          case 1:
        $o->getInventory()->addItem(Item::get($this->efsanekasaid,0,1));
           $o->sendPopUp("§7~ §bWoww Efsanevi Kasa Çıkardın! (1x) §7~");
          break;
          case 2:
        $o->getInventory()->addItem(Item::get($this->vipkasaid,0,1));
           $o->sendPopUp("§7~ §9 Kainat Kasa Çıkardın! (1x) §7~");
          break;
          case 3:
        $o->getInventory()->addItem(Item::get(4,0,1));
           $o->sendPopUp("§7~ §7Kırıktaş Çıkardın! (1x) §7~");
          break;

          case 4:
        $o->getInventory()->addItem(Item::get(264,0,1));
           $o->sendPopUp("§7~ §bElmas Çıkardın! (1x) §7~");
          break;
          case 5:
   $o->getInventory()->addItem(Item::get(263,0,1));
          $o->sendPopUp("§7~ §3Kömür Çıkardın! (1x) §7~");
           break;
   }
          switch($oran2){
          case 0:
          $o->getInventory()->addItem(Item::get(388,0,1));
           $o->sendPopUp("§7~ §aZümrüt Çıkardın! (1x) §7~");
          break;
     }
}
public function ikix($k){
        $o = $k->getPlayer();
		$oran1 = rand(1,85);
		$oran2 = rand(1,175);
		$oran3 = rand(1,65);
		$d = $k->getPlayer()->getLevel()->getFolderName();
		$dunya = $this->plugin->getServer()->getLevelByName($d);
		$x = $k->getBlock()->getX();
		$y = $k->getBlock()->getY();
		$z = $k->getBlock()->getZ();

         switch($oran1){
          case 0:
          $o->getInventory()->addItem(Item::get($this->basitkasaid,0,1));
           $o->sendPopUp("§7~ §aWoow Sıradan Kasa Çıkardın! (2x) §7~");
          break;
          case 1:
        $o->getInventory()->addItem(Item::get($this->efsanekasaid,0,1));
           $o->sendPopUp("§7~ §bWoww Efsanevi Kasa Çıkardın! (2x) §7~");
          break;
          case 2:
        $o->getInventory()->addItem(Item::get($this->vipkasaid,0,1));
           $o->sendPopUp("§7~ Woww §9Kainat Kasa Çıkardın! (2x) §7~");
          break;
          case 3:
        $o->getInventory()->addItem(Item::get(4,0,1));
           $o->sendPopUp("§7~ §7Kırıktaş Çıkardın! (2x) §7~");
          break;

          case 4:
        $o->getInventory()->addItem(Item::get(264,0,1));
           $o->sendPopUp("§7~ §bElmas Çıkardın! (2x) §7~");
          break;
          case 5:
   $o->getInventory()->addItem(Item::get(263,0,1));
          $o->sendPopUp("§7~ §3Kömür Çıkardın! (2x) §7~");
          break;

     }
switch($oran2){
          case 0:
          $o->getInventory()->addItem(Item::get(388,0,1));
           $o->sendPopUp("§7~ §aZümrüt Çıkardın! (1x) §7~");
          break;
     }
}
public function ucix($k){
        $o = $k->getPlayer();
		$oran1 = rand(1,75);
		$oran2 = rand(1,165);
		$oran3 = rand(1,65);
		$d = $k->getPlayer()->getLevel()->getFolderName();
		$dunya = $this->plugin->getServer()->getLevelByName($d);
		$x = $k->getBlock()->getX();
		$y = $k->getBlock()->getY();
		$z = $k->getBlock()->getZ();

         $blok = $k->getBlock;
         switch($oran1){
          case 0:
          $o->getInventory()->addItem(Item::get($this->basitkasaid,0,1));
           $o->sendPopUp("§7~ §aWoow Sıradan Kasa Çıkardın! (3x) §7~");
          break;
          case 1:
        $o->getInventory()->addItem(Item::get($this->efsanekasaid,0,1));
           $o->sendPopUp("§7~ §bWoww Efsanevi Kasa Çıkardın! (3x) §7~");
          break;
          case 2:
        $o->getInventory()->addItem(Item::get($this->vipkasaid,0,1));
           $o->sendPopUp("§7~ §9Kainat Kasa Çıkardın! (3x) §7~");
          break;
          case 3:
        $o->getInventory()->addItem(Item::get(4,0,1));
           $o->sendPopUp("§7~ §7Kırıktaş Çıkardın! (3x) §7~");
          break;

          case 4:
        $o->getInventory()->addItem(Item::get(264,0,1));
           $o->sendPopUp("§7~ §bElmas Çıkardın! (3x) §7~");
          break;
          case 5:
          $dunya->setBlock(new Vector3($blok->getX(), $blok->getY(), $blok->getZ()), Block::get(56));
   $o->getInventory()->addItem(Item::get(263,0,1));
          $o->sendPopUp("§7~ §3Kömür Çıkardın! (3x) §7~");
          break;
     }
switch($oran2){
          case 0:
          $o->getInventory()->addItem(Item::get(388,0,1));
           $o->sendPopUp("§7~ §aZümrüt Çıkardın! (1x) §7~");
          break;
     }
}
public function dix($k){
        $o = $k->getPlayer();
		$oran1 = rand(1,65);
		$oran2 = rand(1,155);
		$oran3 = rand(1,65);
		$d = $k->getPlayer()->getLevel()->getFolderName();
		$dunya = $this->plugin->getServer()->getLevelByName($d);
		$x = $k->getBlock()->getX();
		$y = $k->getBlock()->getY();
		$z = $k->getBlock()->getZ();

         switch($oran1){
          case 0:
          $o->getInventory()->addItem(Item::get($this->basitkasaid,0,1));
           $o->sendPopUp("§7~ §aWoow Sıradan Kasa Çıkardın! (4x) §7~");
          break;
          case 1:
        $o->getInventory()->addItem(Item::get($this->efsanekasaid,0,1));
           $o->sendPopUp("§7~ §bWoww Efsanevi Kasa Çıkardın! (4x) §7~");
          break;
          case 2:
        $o->getInventory()->addItem(Item::get($this->vipkasaid,0,1));
           $o->sendPopUp("§7~ §9Kainat Kasa Çıkardın! (4x) §7~");
          break;
          case 3:
        $o->getInventory()->addItem(Item::get(4,0,1));
           $o->sendPopUp("§7~ §7Kırıktaş Çıkardın! (4x) §7~");
          break;

          case 4:
        $o->getInventory()->addItem(Item::get(264,0,1));
           $o->sendPopUp("§7~ §bElmas Çıkardın! (4x) §7~");
          break;
          case 5:
   $o->getInventory()->addItem(Item::get(263,0,1));
          $o->sendPopUp("§7~ §3Kömür Çıkardın! (4x) §7~");
          break;

     }
     switch($oran2){
          case 0:
          $o->getInventory()->addItem(Item::get(388,0,1));
           $o->sendPopUp("§7~ §aZümrüt Çıkardın! (4x) §7~");
          break;
     }
}
public function besix($k){
      
  $o = $k->getPlayer();
		$oran1 = rand(1,55);
		$oran2 = rand(1,145);
		$oran3 = rand(1,65);
		$d = $k->getPlayer()->getLevel()->getFolderName();
		$dunya = $this->plugin->getServer()->getLevelByName($d);
		$x = $k->getBlock()->getX();
		$y = $k->getBlock()->getY();
		$z = $k->getBlock()->getZ();

         switch($oran1){
          case 0:
          $o->getInventory()->addItem(Item::get($this->basitkasaid,0,1));
           $o->sendPopUp("§7~ §aWoow Sıradan Kasa Çıkardın! (5x) §7~");
          break;
          case 1:
        $o->getInventory()->addItem(Item::get($this->efsanekasaid,0,1));
           $o->sendPopUp("§7~ §bWoww Efsanevi Kasa Çıkardın! (5x) §7~");
          break;
          case 2:
        $o->getInventory()->addItem(Item::get($this->vipkasaid,0,1));
           $o->sendPopUp("§7~ §9VIP Kasa Çıkardın! (5x) §7~");
          break;
          case 3:
        $o->getInventory()->addItem(Item::get(4,0,1));
           $o->sendPopUp("§7~ §7Kırıktaş Çıkardın! (5x) §7~");
          break;

          case 4:
        $o->getInventory()->addItem(Item::get(264,0,1));
           $o->sendPopUp("§7~ §bElmas Çıkardın! (5x) §7~");
          break;
          case 5:
          $o->sendPopUp("§7~ §3Kömür Çıkardın! (5x) §7~");
          break;
     }
switch($oran2){
          case 0:
          $o->getInventory()->addItem(Item::get(388,0,1));
           $o->sendPopUp("§7~ §aZümrüt Çıkardın! (6x) §7~");
          break;
     }
}
public function altix($k){
        $o = $k->getPlayer();
		$oran1 = rand(1,50);
		$oran2 = rand(1,135);
		$oran3 = rand(1,65);
		$d = $k->getPlayer()->getLevel()->getFolderName();
		$dunya = $this->plugin->getServer()->getLevelByName($d);
		$x = $k->getBlock()->getX();
		$y = $k->getBlock()->getY();
		$z = $k->getBlock()->getZ();

         switch($oran1){
          case 0:
          $o->getInventory()->addItem(Item::get($this->basitkasaid,0,1));
           $o->sendPopUp("§7~ §aWoow Sıradan Kasa Çıkardın! (6x) §7~");
          break;
          case 1:
        $o->getInventory()->addItem(Item::get($this->efsanekasaid,0,1));
           $o->sendPopUp("§7~ §bWoww Efsanevi Kasa Çıkardın! (6x) §7~");
          break;
          case 2:
        $o->getInventory()->addItem(Item::get($this->vipkasaid,0,1));
           $o->sendPopUp("§7~ §9Kainat Kasa Çıkardın! (6x) §7~");
          break;
          case 3:
        $o->getInventory()->addItem(Item::get(4,0,1));
           $o->sendPopUp("§7~ §7Kırıktaş Çıkardın! (6x) §7~");
          break;

          case 4:
        $o->getInventory()->addItem(Item::get(264,0,1));
           $o->sendPopUp("§7~ §bElmas Çıkardın! (6x) §7~");
          break;
          case 5:
           $o->getInventory()->addItem(Item::get(263,0,1));
          $o->sendPopUp("§7~ §3Kömür Çıkardın! (6x) §7~");
          break;

     }
switch($oran2){
          case 0:
          $o->getInventory()->addItem(Item::get(388,0,1));
           $o->sendPopUp("§7~ §aZümrüt Çıkardın! (6x) §7~");
          break;
     }
}
public function yedix($k){
        $o = $k->getPlayer();
		$oran1 = rand(1,35);
		$oran2 = rand(1,125);
		$oran3 = rand(1,65);
		$d = $k->getPlayer()->getLevel()->getFolderName();
		$dunya = $this->plugin->getServer()->getLevelByName($d);
		$x = $k->getBlock()->getX();
		$y = $k->getBlock()->getY();
		$z = $k->getBlock()->getZ();

         switch($oran1){
          case 0:
          $o->getInventory()->addItem(Item::get($this->basitkasaid,0,1));
           $o->sendPopUp("§7~ §aWoow Sıradan Kasa Çıkardın! (7x) §7~");
          break;
          case 1:
        $o->getInventory()->addItem(Item::get($this->efsanekasaid,0,1));
           $o->sendPopUp("§7~ §bWoww Efsanevi Kasa Çıkardın! (7x) §7~");
          break;
          case 2:
        $o->getInventory()->addItem(Item::get($this->vipkasaid,0,1));
           $o->sendPopUp("§7~ §9Kainat Kasa Çıkardın! (7x) §7~");
          break;
          case 3:
        $o->getInventory()->addItem(Item::get(4,0,1));
           $o->sendPopUp("§7~ §7Kırıktaş Çıkardın! (7x) §7~");
          break;

         case 4:

        $o->getInventory()->addItem(Item::get(264,0,1));
           $o->sendPopUp("§7~ §bElmas Çıkardın! (7x) §7~");
          break;
          case 5:
   $o->getInventory()->addItem(Item::get(263,0,1));
          $o->sendPopUp("§7~ §3Kömür Çıkardın! (7x) §7~");
          break;

     }
switch($oran2){
          case 0:
          $o->getInventory()->addItem(Item::get(388,0,1));
           $o->sendPopUp("§7~ §aZümrüt Çıkardın! (7x) §7~");
          break;
     }
}
public function sekizix($k){
        $o = $k->getPlayer();
		$oran1 = rand(1,25);
		$oran2 = rand(1,1);
		$oran3 = rand(1,23);
		$d = $k->getPlayer()->getLevel()->getFolderName();
		$dunya = $this->plugin->getServer()->getLevelByName($d);
		$x = $k->getBlock()->getX();
		$y = $k->getBlock()->getY();
		$z = $k->getBlock()->getZ();

         $blok = $k->getBlock();
         switch($oran1){

          case 0:
          $o->getInventory()->addItem(Item::get($this->basitkasaid,0,1));
           $o->sendPopUp("§7~ §aWoow Sıradan Kasa Çıkardın! (8x) §7~");
          break;
          case 1:
        $o->getInventory()->addItem(Item::get($this->efsanekasaid,0,1));
           $o->sendPopUp("§7~ §bWoww Efsanevi Kasa Çıkardın! (8x) §7~");
          break;
          case 2:
        $o->getInventory()->addItem(Item::get($this->vipkasaid,0,1));
           $o->sendPopUp("§7~ §9Kainat Kasa Çıkardın! (8x) §7~");
          break;
          case 3:
        $o->getInventory()->addItem(Item::get(4,0,1));
           $o->sendPopUp("§7~ §7Kırıktaş Çıkardın! (8x) §7~");
          break;

          case 4:
        $o->getInventory()->addItem(Item::get(264,0,1));
           $o->sendPopUp("§7~ §bElmas Çıkardın! (8x) §7~");
          break;
          case 5:
        $dunya->setBlock(new Vector3($blok->getX(), $blok->getY(), $blok->getZ()), Block::get(15));
       $o->getInventory()->addItem(Item::get(263,0,1));
          $o->sendPopUp("§7~ §3Kömür Çıkardın! (8x) §7~");
          break;

     }
switch($oran2){
          case 0:
          $o->getInventory()->addItem(Item::get(388,0,1));
           $o->sendPopUp("§7~ §aZümrüt Çıkardın! (8x) §7~");
          break;
     }
}
}